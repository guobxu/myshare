package app.autodig.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.springframework.http.HttpStatus;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ResponseDto implements Serializable {

    private int code;               // HTTP code
    private String message;         // 错误消息 1. 域名及监控及监控类型已存在 2. 其他

    private String token;           // 认证token
    private String expireDatetime;  // 认证过期时间

    private String taskId;
    private String messageSN;

    public static ResponseDto errorByCodeAndMessage(int code, String message) {
        ResponseDto dto = new ResponseDto();
        dto.code = code;
        dto.message = message;

        return dto;
    }

    public static ResponseDto badRequest(String message) {
        ResponseDto dto = new ResponseDto();
        dto.code = HttpStatus.BAD_REQUEST.value();
        dto.message = message;

        return dto;
    }


    public static ResponseDto authSuccess(String token, String expireDatetime, String messageSN) {
        ResponseDto dto = new ResponseDto();
        dto.code = HttpStatus.OK.value();
        dto.token = token;
        dto.expireDatetime = expireDatetime;
        dto.messageSN = messageSN;

        return dto;
    }

    public static ResponseDto taskOpTokenError(String taskId, String messageSN) {
        ResponseDto dto = new ResponseDto();
        dto.code = HttpStatus.BAD_REQUEST.value();
        dto.taskId = taskId;
        dto.messageSN = messageSN;
        dto.message = "token认证失败";

        return dto;
    }

    public static ResponseDto taskOpSuccess(String taskId, String messageSN) {
        ResponseDto dto = new ResponseDto();
        dto.code = HttpStatus.OK.value();
        dto.taskId = taskId;
        dto.messageSN = messageSN;

        return dto;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public String getMessageSN() {
        return messageSN;
    }

    public void setMessageSN(String messageSN) {
        this.messageSN = messageSN;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getExpireDatetime() {
        return expireDatetime;
    }

    public void setExpireDatetime(String expireDatetime) {
        this.expireDatetime = expireDatetime;
    }
}
