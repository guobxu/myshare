package app.autodig.dto;

import org.hibernate.validator.constraints.NotBlank;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import java.io.Serializable;

public class TaskOpDto implements Serializable {

    @NotBlank
    private String taskId;
    @NotBlank
    private String messageSN;

    private String domain;

    @Min(1) @Max(6)
    private Integer monitorType;        // 监控类型 1 - A记录 2 - AAAA记录 3 - CNAME 4 - NS 5 - MX 6 - TXT

    private String monitorValue;        // DNS服务器IP

    @Min(1) @Max(2)
    private Integer taskTycleType;      // 1 周期任务 2 一次性任务

    // @Min(1) @Max(2)
    private Integer monitorLevel;       // 监控级别 1 高级版周期10分钟 2 基础版周期30分钟 NULL 一次性

    private String monitorStartTime; // 周期任务监控开始时间 一次性和无限周期任务为NULL, 格式: '2021/12/11 13:11:20'
    private String monitorEndTime;   // 周期任务监控结束时间 一次性和无限周期任务为NULL

    // 操作类型
    // add 新增
    // renew 更新, 只能变更监控值及加快等级, 不可以变更其他参数
    // close 关闭, 入参为监控域名 和 监控值
    @NotBlank
    private String opType;

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public String getMessageSN() {
        return messageSN;
    }

    public void setMessageSN(String messageSN) {
        this.messageSN = messageSN;
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    public Integer getMonitorType() {
        return monitorType;
    }

    public void setMonitorType(Integer monitorType) {
        this.monitorType = monitorType;
    }

    public String getMonitorValue() {
        return monitorValue;
    }

    public void setMonitorValue(String monitorValue) {
        this.monitorValue = monitorValue;
    }

    public Integer getTaskTycleType() {
        return taskTycleType;
    }

    public void setTaskTycleType(Integer taskTycleType) {
        this.taskTycleType = taskTycleType;
    }

    public Integer getMonitorLevel() {
        return monitorLevel;
    }

    public void setMonitorLevel(Integer monitorLevel) {
        this.monitorLevel = monitorLevel;
    }

    public String getMonitorStartTime() {
        return monitorStartTime;
    }

    public void setMonitorStartTime(String monitorStartTime) {
        this.monitorStartTime = monitorStartTime;
    }

    public String getMonitorEndTime() {
        return monitorEndTime;
    }

    public void setMonitorEndTime(String monitorEndTime) {
        this.monitorEndTime = monitorEndTime;
    }

    public String getOpType() {
        return opType;
    }

    public void setOpType(String opType) {
        this.opType = opType;
    }

}
