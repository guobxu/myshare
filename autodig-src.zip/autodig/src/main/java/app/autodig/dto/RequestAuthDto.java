package app.autodig.dto;

import org.hibernate.validator.constraints.NotBlank;

import java.io.Serializable;

public class RequestAuthDto implements Serializable {

    private String systemID;

    @NotBlank
    private String hashCode;

    @NotBlank
    private String messageSN;

    public String getSystemID() {
        return systemID;
    }

    public void setSystemID(String systemID) {
        this.systemID = systemID;
    }

    public String getHashCode() {
        return hashCode;
    }

    public void setHashCode(String hashCode) {
        this.hashCode = hashCode;
    }

    public String getMessageSN() {
        return messageSN;
    }

    public void setMessageSN(String messageSN) {
        this.messageSN = messageSN;
    }

}
