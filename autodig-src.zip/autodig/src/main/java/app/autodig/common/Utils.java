package app.autodig.common;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.io.Closeable;
import java.io.IOException;
import java.security.SecureRandom;
import java.sql.Timestamp;
import java.util.Base64;
import java.util.List;
import java.util.UUID;

public class Utils {

    private static final Logger LOGGER = LoggerFactory.getLogger(Utils.class);

    private static final String AES = "AES";
    protected static final char[] HEX_ARRAY= {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};

    public static final boolean isBlank(String s) {
        return s == null || s.trim().length() == 0;
    }

    public static final boolean isNotBlank(String s) {
        return !isBlank(s);
    }

    public static final void closeQuietly(Closeable... resources) {
        for(Closeable resource : resources) {
            try {
                resource.close();
            } catch(IOException ex) {
                LOGGER.error(ex.getMessage(), ex);
            }
        }
    }

    public static final <T> boolean isEmpty(List<T> list) {
        return list == null || list.isEmpty();
    }

    public static final <T> boolean isNotEmpty(List<T> list) {
        return list != null && list.size() > 0;
    }

    public static final String uuid() {
        return UUID.randomUUID().toString().replace("-", "");
    }

    // 小于或等于当前时间
    public static boolean notAfterNow(Timestamp ts) {
        return ts.getTime() <= System.currentTimeMillis();
    }

    // 大于或等于当前时间
    public static boolean notBeforeNow(Timestamp ts) {
        return ts.getTime() >= System.currentTimeMillis();
    }

    // 时间相加, 单位: 秒
    public static Timestamp dateAdd(Timestamp ts, long seconds) {
        return new Timestamp(ts.getTime() + seconds * 1000);
    }

    public static final String encryptAES(String text, String key) throws Exception {
        KeyGenerator kgen = KeyGenerator.getInstance(AES);
        SecureRandom secureRandom = SecureRandom.getInstance("SHA1PRNG");
        secureRandom.setSeed(key.getBytes());
        kgen.init(128, secureRandom);
        SecretKey secretKey = kgen.generateKey();
        byte[] encBytes = secretKey.getEncoded();
        SecretKeySpec keySpec = new SecretKeySpec(encBytes, AES);

        Cipher cipher = Cipher.getInstance(AES);
        cipher.init(Cipher.ENCRYPT_MODE, keySpec);
        byte[] bytes = cipher.doFinal(text.getBytes("utf-8"));
        String hexStr = bytesToHex(bytes);
        byte[] base64Bytes = Base64.getEncoder().encode(hexStr.getBytes());
        String encrypted = new String(base64Bytes, "utf-8");

        return encrypted;
    }

    public static final String decryptAES(String encrypted, String key) throws Exception {
        KeyGenerator kgen = KeyGenerator.getInstance(AES);
        SecureRandom secureRandom = SecureRandom.getInstance("SHA1PRNG");
        secureRandom.setSeed(key.getBytes());
        kgen.init(128, secureRandom);
        SecretKey secretKey = kgen.generateKey();
        byte[] encBytes = secretKey.getEncoded();
        SecretKeySpec keySpec = new SecretKeySpec(encBytes, AES);

        Cipher cipher = Cipher.getInstance(AES);
        cipher.init(Cipher.DECRYPT_MODE, keySpec);
        byte[] base64Bytes = encrypted.getBytes("utf-8");
        String hexStr = new String(Base64.getDecoder().decode(base64Bytes));
        byte[] bytes = cipher.doFinal(hexToBytes(hexStr));
        String text = new String(bytes, "utf-8");

        return text;
    }

    private static String bytesToHex(byte[] bytes) {
        char[] hexChars = new char[bytes.length * 2];
        for (int j = 0; j < bytes.length; j++) {
            int v = bytes[j] & 0xFF;
            hexChars[j * 2] = HEX_ARRAY[v >>> 4];
            hexChars[j * 2 + 1] = HEX_ARRAY[v & 0x0F];
        }

        return new String(hexChars);
    }

    private static byte[] hexToBytes(String hexStr) {
        byte[] result = new byte[hexStr.length() / 2];

        for(int i = 0; i < hexStr.length() / 2; ++i) {
            int high = Integer.parseInt(hexStr.substring(i * 2, i * 2 + 1), 16);
            int low = Integer.parseInt(hexStr.substring(i * 2 + 1, i * 2 + 2), 16);
            result[i] = (byte)(high * 16 + low);
        }

        return result;
    }

}


