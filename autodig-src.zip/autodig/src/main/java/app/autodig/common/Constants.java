package app.autodig.common;

public class Constants {

    public static final String ENC_KEY = "5A9968015C729323BF212B74E919DA98";

    public static final String DATE_FORMAT = "yyyy/MM/dd HH:mm:ss";

    public static final String BEARER_TOKEN_PREFIX = "Bearer ";

}
