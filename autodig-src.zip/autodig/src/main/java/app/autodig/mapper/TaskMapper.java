package app.autodig.mapper;

import app.autodig.entity.Task;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TaskMapper {

    void insertTask(Task task);

    int countByDomainAndType(@Param("domain") String domain,
                             @Param("monitorType") Integer monitorType,
                             @Param("taskCycleType") Integer taskCycleType);

    Task selectById(String taskId);

    void updateTaskMonitorLevel(@Param("taskId") String taskId, @Param("monitorLevel") Integer monitorLevel);

//    void markClose(@Param("domain") String domain, @Param("monitorValue") String monitorValue);

    void markCloseByTaskId(String taskId);

    List<Task> listOpenTask();


}
