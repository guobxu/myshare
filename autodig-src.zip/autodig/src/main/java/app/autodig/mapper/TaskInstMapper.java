package app.autodig.mapper;

import app.autodig.entity.TaskInst;
import org.springframework.stereotype.Repository;

@Repository
public interface TaskInstMapper {

    void insertInst(TaskInst inst);

}
