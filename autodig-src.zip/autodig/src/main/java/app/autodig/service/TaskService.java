package app.autodig.service;

import app.autodig.dto.ResponseDto;
import app.autodig.dto.TaskOpDto;

public interface TaskService {

    ResponseDto opTask(TaskOpDto dto);

}
