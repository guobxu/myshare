package app.autodig.service;

public interface TaskExecutorService {

    void scheduleTaskNow(String taskId);

    void scheduleTask(String taskId, long delay);

    void runTask(String taskId);

}
