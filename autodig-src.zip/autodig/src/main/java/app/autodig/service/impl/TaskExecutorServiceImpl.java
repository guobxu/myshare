package app.autodig.service.impl;

import app.autodig.common.Constants;
import app.autodig.entity.MonitorType;
import app.autodig.entity.Task;
import app.autodig.entity.TaskInst;
import app.autodig.mapper.TaskInstMapper;
import app.autodig.mapper.TaskMapper;
import app.autodig.service.TaskExecutorService;
import app.autodig.common.Utils;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;

@Service
public class TaskExecutorServiceImpl implements InitializingBean, TaskExecutorService {

    private static final Logger LOGGER = LoggerFactory.getLogger(TaskExecutorServiceImpl.class);

    @Autowired
    private TaskMapper taskMapper;

    @Value("${task.coreThreads:10}")
    private int taskCoreThreads;

    @Value("${cmd.dig.opts:}")
    private String cmdDigOpts;

    @Value("${cmd.logger.opts:}")
    private String cmdLoggerOpts;

    @Value("${node.hostName:}")
    private String nodeHost;

    @Value("${node.ip:}")
    private String nodeIp;

    private ScheduledExecutorService executorService;

    @Value("${cmd.timeout:10}")
    private long cmdTimeout;

    @Autowired
    private TaskInstMapper taskInstMapper;

    public static final String lineSep = System.getProperty("line.separator");

    /**
     * 立即执行任务
     * @param taskId
     */
    @Override
    public void scheduleTaskNow(String taskId) {
        scheduleTask(taskId, 0L);
    }

    /**
     * 调度任务执行在delay(s)之后
     * @param taskId
     * @param delay
     */
    @Override
    public void scheduleTask(String taskId, long delay) {
        executorService.schedule(() -> {
            try {
                runTask(taskId);
            } catch(Exception ex) {
                LOGGER.error(ex.getMessage(), ex);
            }
        }, delay, TimeUnit.SECONDS);
    }

    /**
     * 调度执行任务
     * @param taskId 任务id
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void runTask(String taskId) {
        Task task = taskMapper.selectById(taskId);
        if(task == null || task.getCloseMark() == 1) {
            LOGGER.info("任务ID = {}不存在或者已关闭，停止执行", taskId);
            return;
        }

        Integer monitorType = task.getMonitorType();
        String domain = task.getDomain(), monitorTypeVal = MonitorType.get(monitorType);

        // 初始化任务实例
        TaskInst inst = new TaskInst();
        inst.setInstId(Utils.uuid());
        inst.setTaskId(taskId);
        inst.setDomain(domain);
        inst.setMonitorType(monitorType);
        inst.setNodeName(nodeHost);
        inst.setNodeIp(nodeIp);

        Timestamp recordTime = new Timestamp(System.currentTimeMillis());
        inst.setRecordTime(recordTime);

        // 执行dig
        String digCmd = String.format("dig +nocmd +noall +answer %s %s %s", cmdDigOpts, domain, monitorTypeVal);
        CmdResult digResult = execCmd(digCmd, cmdTimeout);

        // 实例dig信息
        List<String> digStdOutput = digResult.stdOutput, digErrOutput = digResult.errOutput;
        inst.setDigStdOutput(digStdOutput == null ? null : String.join(lineSep, digStdOutput));
        inst.setDigErrOutput(digErrOutput == null ? null : String.join(lineSep, digErrOutput));
        if(digResult.hasError()) {  // dig命令出错
            inst.setErrMsg(digResult.errMsg);

            taskInstMapper.insertInst(inst);
        } else {                    // dig成功
            List<String> values = parseDigOutput(digStdOutput, monitorTypeVal);
            String cmdValue = values.isEmpty() ? "" : (values.size() == 1 ? values.get(0) : String.join(",", values));

            // 日志信息
            StringBuilder logBuf = new StringBuilder();
            logBuf.append("{");
            logBuf.append(String.format("\"%s\": \"%s\"", "record_time", new SimpleDateFormat(Constants.DATE_FORMAT).format(recordTime))).append(", ");
            logBuf.append(String.format("\"%s\": \"%s\"", "taskId", taskId)).append(", ");
            logBuf.append(String.format("\"%s\": \"%s\"", "domain", domain)).append(", ");
            logBuf.append(String.format("\"%s\": \"%s\"", "monitor_type", monitorType)).append(", ");
            logBuf.append(String.format("\"%s\": \"%s\"", "node_name", nodeHost)).append(", ");
            logBuf.append(String.format("\"%s\": \"%s\"", "node_ip", nodeIp)).append(", ");
            logBuf.append(String.format("\"%s\": \"%s\"", "value", cmdValue));
            logBuf.append("}");
//            JSONObject loggerObj = new JSONObject();
//            loggerObj.put("taskId", taskId);
//            loggerObj.put("domain", domain);
//            // loggerObj.put("monitorValue", monitorValue);
//            loggerObj.put("monitor_type", monitorType);
//            loggerObj.put("node_name", nodeHost);
//            loggerObj.put("node_ip", nodeIp);
//            loggerObj.put("value", cmdValue);
//            loggerObj.put("record_time", new SimpleDateFormat(Constants.DATE_FORMAT).format(recordTime));

            // 发送logger
            // String loggerCmd = String.format("logger %s \"%s\"", cmdLoggerOpts, JSONObject.toJSONString(loggerObj, SerializerFeature.UseSingleQuotes));
            String loggerCmd = String.format("logger %s '%s'", cmdLoggerOpts, logBuf.toString());
            CmdResult loggerResult = execCmd(loggerCmd, cmdTimeout);

            inst.setValue(cmdValue instanceof String ? (String)cmdValue : JSONObject.toJSONString(cmdValue));
            List<String> loggerStdOutput = loggerResult.stdOutput, loggerErrOutput = loggerResult.errOutput;
            inst.setLoggerStdOutput(loggerStdOutput == null ? null : String.join(lineSep, loggerStdOutput));
            inst.setLoggerErrOutput(loggerErrOutput == null ? null : String.join(lineSep, loggerErrOutput));
            inst.setErrMsg(loggerResult.errMsg);

            taskInstMapper.insertInst(inst);
        }

        // 是否周期任务
        long interval = task.getSchedInterval();
        Timestamp endTime = task.getMonitorEndTime();
        if(interval == 0 ||
                (endTime != null && endTime.getTime() < (System.currentTimeMillis() + interval * 1000))) {
            taskMapper.markCloseByTaskId(taskId);
        } else {
            scheduleTask(taskId, interval);
        }
    }

    /**
     * 解析dig输出, 返回结果ip地址
     * @param digOutput
     * @param monitorType 监控类型 A | AAAA | NS...
     * @return 可能有多个值
     */
    private List<String> parseDigOutput(List<String> digOutput, String monitorType) {
        List<String> result = new ArrayList<>();
        if(digOutput == null) return result;

        for(String line : digOutput) {
            if(MonitorType.isTXT(monitorType)) { // 针对TXT处理
                result.add(line.substring(line.indexOf("\"") + 1, line.length() -1));
            } else {
                String[] fields = line.split("\\s+");
                for(int i = 0, len = fields.length; i < len; i++) {
                    if(monitorType.equals(fields[i])) {
                        result.add(fields[len -1]);
                        break;
                    }
                }
            }
        }
        return result;
    }

    /**
     * 执行命令并返回结果
     * @param cmd
     * @param cmdTimeout
     * @return 命令执行结果
     */
    private CmdResult execCmd(String cmd, long cmdTimeout) {
        LOGGER.info("开始执行命令 = {}", cmd);
        ProcessBuilder builder = new ProcessBuilder().command("bash", "-c", cmd);
        builder.environment().put("LANG", "en_US.UTF-8");
//        ProcessBuilder builder = new ProcessBuilder().command("cmd.exe", "/c", "ping -n 3 www.baidu.com");

//        builder.redirectErrorStream(true); // 合并错误和标准输出

        Process process = null;
        BufferedReader stdReader = null, errReader = null;
        try {
            process = builder.start();
            process.waitFor(cmdTimeout, TimeUnit.SECONDS);

            stdReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            errReader = new BufferedReader(new InputStreamReader(process.getErrorStream()));
            List<String> stdOutput = readLines(stdReader), errOutput = readLines(errReader);
//            int exitCode = process.exitValue();

            return new CmdResult(0, stdOutput, errOutput, null);
        } catch(Exception ex) { // IOException | InterruptedException ex
            LOGGER.error(ex.getMessage(), ex);

            return new CmdResult(null, null, null, ex.getMessage());
        } finally {
            Utils.closeQuietly(stdReader, errReader);

            if(process != null) {
                try {
                    process.destroyForcibly();
                } catch(Throwable ex) {
                    LOGGER.error(ex.getMessage(), ex);
                }
            }
        }
    }

    private static class CmdResult {

        Integer exitCode;       // 命令退出状态
        List<String> stdOutput;       // 标准输出, null或者非空
        List<String> errOutput;       // 错误输出, null或者非空
        String errMsg;          // 异常消息

        CmdResult(Integer exitCode, List<String> stdOutput, List<String> errOutput, String errMsg) {
            this.exitCode = exitCode;
            this.stdOutput = stdOutput;
            this.errOutput = errOutput;
            this.errMsg = errMsg;
        }

        boolean hasError() {    // 是否有错误
            return Utils.isNotEmpty(errOutput) || errMsg != null;
        }

    }

    // 没有输出返回null, 否则返回非空数组
    private static List<String> readLines(BufferedReader reader) throws IOException {
        List<String> result = null;
        String line = null;
        while(( line = reader.readLine() ) != null) {
            if(result == null) {
                result = new ArrayList<>();
            }

            result.add(line);
        }

        return result;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        executorService = Executors.newScheduledThreadPool(taskCoreThreads);

        try {
            InetAddress localAddr = InetAddress.getLocalHost();
            if(Utils.isBlank(nodeHost)) {
                nodeHost = localAddr.getHostName();
            }
            if(Utils.isBlank(nodeIp)) {
                nodeIp = localAddr.getHostAddress();
            }
        } catch(UnknownHostException ex) {
            LOGGER.error("无法获取本地hostName 和 ip：" + ex.getMessage(), ex);
        }

        LOGGER.info("nodeHost = {}, nodeIp = {}", nodeHost, nodeIp);
    }

}
