package app.autodig.service.impl;

import app.autodig.dto.ResponseDto;
import app.autodig.dto.TaskOpDto;
import app.autodig.entity.Task;
import app.autodig.mapper.TaskMapper;
import app.autodig.service.TaskExecutorService;
import app.autodig.service.TaskService;
import app.autodig.common.Utils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.net.Inet4Address;
import java.net.Inet6Address;
import java.net.UnknownHostException;
import java.security.SecureRandom;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static app.autodig.entity.Task.ONCE;
import static app.autodig.entity.Task.REPEATED;

@Service
public class TaskServiceImpl implements TaskService, InitializingBean {

    private static final Logger LOGGER = LoggerFactory.getLogger(TaskServiceImpl.class);

    @Autowired
    private TaskMapper taskMapper;

    @Autowired
    private TaskExecutorService taskExecutor;

    @Override
    public ResponseDto opTask(TaskOpDto dto) {
        String opType = dto.getOpType();
        if("add".equals(opType)) {
            return opAddTask(dto);
        } else if("renew".equals(opType)) {
            return opRenewTask(dto);
        } else if("close".equals(opType)) {
            return opCloseTask(dto);
        }

        return ResponseDto.errorByCodeAndMessage(HttpStatus.BAD_REQUEST.value(), "错误的opType参数");
    }

    /**
     * 新建任务
     * @param dto
     * @return
     */
    private ResponseDto opAddTask(TaskOpDto dto) {
        String taskId = dto.getTaskId(), messageSN = dto.getMessageSN(), domain = dto.getDomain(), monitorValue = dto.getMonitorValue(),
            startTimeStr = dto.getMonitorStartTime(), endTimeStr = dto.getMonitorEndTime();
        Integer monitorType = dto.getMonitorType(), taskCycleType = dto.getTaskTycleType(), monitorLevel = dto.getMonitorLevel();

        // 解析开始/结束日期
        Timestamp startTime = null, endTime = null;
        if(taskCycleType == REPEATED) {
            try {
                startTime = nullOrValidDate(startTimeStr);
                endTime = nullOrValidDate(endTimeStr);
            } catch(ParseException ex) {
                LOGGER.error(ex.getMessage(), ex);
                return ResponseDto.badRequest("错误的请求参数，monitorStartTime monitorEndTime必须合法的时间格式");
            }
        }

        // 校验参数
        if(messageSN == null) {
            return ResponseDto.badRequest("错误的请求参数，messageSN是必须的");
        } else if(domain == null) {
            return ResponseDto.badRequest("错误的请求参数，domain是必须的");
        } else if(monitorType == null) {
            return ResponseDto.badRequest("错误的请求参数，monitorType是必须的");
        } else if(taskCycleType == null) {
            return ResponseDto.badRequest("错误的请求参数，taskTycleType是必须的");
        } else if( taskCycleType == REPEATED && (monitorLevel == null || (monitorLevel != 1 && monitorLevel != 2))) {
            return ResponseDto.badRequest("错误的请求参数，请设置正确的monitorLevel");
        } else if( taskCycleType == REPEATED && startTime != null && endTime != null && startTime.compareTo(endTime) >= 0) {
            return ResponseDto.badRequest("错误的请求参数，monitorStartTime必须小于monitorEndTime");
        } else if( taskCycleType == REPEATED && endTime != null && Utils.notAfterNow(endTime) ) {
            return ResponseDto.badRequest("错误的请求参数，monitorEndTime必须大于当前时间");
        }

        // 检查域名及监控类型是否重复
        if(taskCycleType == REPEATED && taskMapper.countByDomainAndType(domain, monitorType, REPEATED) > 0) {
            return ResponseDto.badRequest("此域名和监控类型的周期性任务已配置，请勿重复配置！");
        }

        // 写入数据库
        Task task = new Task();
        task.setTaskId(taskId);
        task.setMessageSN(messageSN);
        task.setDomain(domain);
        task.setMonitorType(monitorType);
        task.setMonitorValue(monitorValue);
        task.setTaskCycleType(taskCycleType);
        if(taskCycleType == REPEATED) {
            task.setMonitorLevel(monitorLevel);

            task.setMonitorStartTime(startTime);
            task.setMonitorEndTime(endTime);
        }

        taskMapper.insertTask(task);

        // 执行任务
        if(task.getSchedInterval() == 0 || startTime == null || Utils.notAfterNow(startTime)) {   // 一次性或周期任务小于当前时间
            taskExecutor.scheduleTaskNow(taskId);
        } else {
            long delay = (startTime.getTime() - System.currentTimeMillis()) / 1000;         // 周期任务大于当前时间开始
            taskExecutor.scheduleTask(taskId, delay);
        }

        return ResponseDto.taskOpSuccess(taskId, messageSN);
    }



    /**
     * 更新任务, 只能变更监控值及加快等级, 不可以变更其他参数
     * @param dto
     * @return
     */
    private ResponseDto opRenewTask(TaskOpDto dto) {
        String taskId = dto.getTaskId(), messageSN = dto.getMessageSN(), domain = dto.getDomain(), monitorValue = dto.getMonitorValue();
        Integer monitorLevel = dto.getMonitorLevel();

        Task task = taskMapper.selectById(taskId);
        if(task == null || task.getCloseMark() == 1) {
            return ResponseDto.badRequest("任务不存在，或者已关闭");
        }

        // 请求参数校验
//        if( ( messageSN != null && !messageSN.equals(task.getMessageSN()) )
//            || ( domain != null && !domain.equals(task.getDomain()) )) {
//            return ResponseDto.badRequest("错误的请求参数，messageSN 或者 domain不匹配");
//        }

        // 更新任务
//        Task updateTask = new Task();
//        updateTask.setTaskId(taskId);
//        if(monitorValue != null) {  // 监控值
//            if(!isValidIP(monitorValue)) {
//                return ResponseDto.badRequest("错误的请求参数，monitorValue不是合法的IP地址");
//            } else {
//                updateTask.setMonitorValue(monitorValue);
//            }
//        }

        if(monitorLevel == null) {
            return ResponseDto.badRequest("错误的请求参数，monitorLevel不能为空");
        }

        taskMapper.updateTaskMonitorLevel(taskId, monitorLevel);

        return ResponseDto.taskOpSuccess(taskId, messageSN);
    }

    /**
     * 关闭任务, 入参为监控域名 和 监控值
     * @param dto
     * @return
     */
    private ResponseDto opCloseTask(TaskOpDto dto) {
        String taskId = dto.getTaskId(), messageSN = dto.getMessageSN();
//        if(domain == null || monitorValue == null) {
//            return ResponseDto.badRequest("错误的请求参数，domain 和 monitorValue不能为空");
//        }

        taskMapper.markCloseByTaskId(taskId);

        return ResponseDto.taskOpSuccess(taskId, messageSN);
    }

    private Timestamp nullOrValidDate(String dateStr) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Pattern p1 = Pattern.compile("(\\d{4})/(\\d{1,2})/(\\d{1,2}) (\\d{2}:\\d{2}:\\d{2})"),
                p2 = Pattern.compile("(\\d{4})-(\\d{1,2})-(\\d{1,2}) (\\d{2}:\\d{2}:\\d{2})");

        if(Utils.isBlank(dateStr)) return null;

        String normalizedStr = dateStr;
        Matcher m = p1.matcher(dateStr);
        if(m.matches()) {
            normalizedStr = String.format("%s/%s/%s %s", m.group(1), lpad0(m.group(2)), lpad0(m.group(3)), m.group(4));
        } else {
            m = p2.matcher(dateStr);
            if(m.matches()) {
                normalizedStr = String.format("%s/%s/%s %s", m.group(1), lpad0(m.group(2)), lpad0(m.group(3)), m.group(4));
            }
        }

        return new Timestamp( sdf.parse(normalizedStr).getTime() );
    }

    private String lpad0(String s) {
        return s.length() == 1 ? String.format("0%s", s) : s;
    }

    private boolean isValidIP(String ip) {
        return isValidIPv4(ip) || isValidIPv6(ip);
    }

    private boolean isValidIPv4(String ip) {
        try {
            Inet4Address.getByName(ip);
        } catch(UnknownHostException ex) {
            LOGGER.error(ex.getMessage(), ex);

            return false;
        }

        return true;
    }

    private boolean isValidIPv6(String ip) {
        try {
            Inet6Address.getByName(ip);
        } catch(UnknownHostException ex) {
            LOGGER.error(ex.getMessage(), ex);

            return false;
        }

        return true;
    }

//    private Timestamp parseTime(String time, SimpleDateFormat sdf) {
//        if(time == null) {
//            return null;
//        }
//
//        try {
//            return new Timestamp(sdf.parse(time).getTime());
//        } catch(ParseException ex) {
//            throw new RuntimeException(ex.getMessage(), ex);
//        }
//    }

    @Override
    public void afterPropertiesSet() throws Exception {
        List<Task> openTasks = taskMapper.listOpenTask();
        int taskSize = openTasks.size();
        LOGGER.info("需继续执行未关闭任务条数 = {}", taskSize);
        SecureRandom rand = new SecureRandom(); // 随机数, 以taskSize为 bound

        for(Task task : openTasks) { // 执行任务
            String taskId = task.getTaskId();
            Timestamp endTime = task.getMonitorEndTime();

            if(task.getSchedInterval() == 0) {  // 一次性任务
                taskExecutor.scheduleTask(taskId, rand.nextInt(taskSize));
            } else if(endTime == null || Utils.notBeforeNow(endTime)){  // 周期性任务, 未设置结束时间 或 结束时间未到达
                taskExecutor.scheduleTask(taskId, rand.nextInt(taskSize));
            }
        }
    }

}
