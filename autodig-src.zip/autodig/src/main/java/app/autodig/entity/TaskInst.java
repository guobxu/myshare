package app.autodig.entity;

import java.io.Serializable;
import java.sql.Timestamp;

public class TaskInst implements Serializable {

    private String instId;
    private String taskId;
    private String domain;
    // private String monitorValue;
    private Integer monitorType;
    private String nodeName;
    private String nodeIp;
    private String value;
    private String digStdOutput;
    private String digErrOutput;
    private String loggerStdOutput;
    private String loggerErrOutput;
    private String errMsg;
    private Timestamp recordTime;

    public String getInstId() {
        return instId;
    }

    public void setInstId(String instId) {
        this.instId = instId;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    public Integer getMonitorType() {
        return monitorType;
    }

    public void setMonitorType(Integer monitorType) {
        this.monitorType = monitorType;
    }

    public String getNodeName() {
        return nodeName;
    }

    public void setNodeName(String nodeName) {
        this.nodeName = nodeName;
    }

    public String getNodeIp() {
        return nodeIp;
    }

    public void setNodeIp(String nodeIp) {
        this.nodeIp = nodeIp;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getDigStdOutput() {
        return digStdOutput;
    }

    public void setDigStdOutput(String digStdOutput) {
        this.digStdOutput = digStdOutput;
    }

    public String getDigErrOutput() {
        return digErrOutput;
    }

    public void setDigErrOutput(String digErrOutput) {
        this.digErrOutput = digErrOutput;
    }

    public String getLoggerStdOutput() {
        return loggerStdOutput;
    }

    public void setLoggerStdOutput(String loggerStdOutput) {
        this.loggerStdOutput = loggerStdOutput;
    }

    public String getLoggerErrOutput() {
        return loggerErrOutput;
    }

    public void setLoggerErrOutput(String loggerErrOutput) {
        this.loggerErrOutput = loggerErrOutput;
    }

    public String getErrMsg() {
        return errMsg;
    }

    public void setErrMsg(String errMsg) {
        this.errMsg = errMsg;
    }

    public Timestamp getRecordTime() {
        return recordTime;
    }

    public void setRecordTime(Timestamp recordTime) {
        this.recordTime = recordTime;
    }

}
