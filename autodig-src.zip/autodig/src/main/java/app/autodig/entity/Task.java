package app.autodig.entity;

import java.io.Serializable;
import java.sql.Timestamp;

public class Task implements Serializable {

    // 周期类型
    public static final int REPEATED = 1;   // 周期任务
    public static final int ONCE = 2;       // 一次性

    private String taskId;
    private String messageSN;
    private String domain;
    private Integer monitorType;        // 监控类型 1 - A记录 2 - AAAA记录 3 - CNAME 4 - NS 5 - MX 6 - TXT
    private String monitorValue;        // DNS服务器IP
    private Integer taskCycleType;      // 1 周期任务 2 一次性任务
    private Integer monitorLevel;       // 监控级别 1 高级版周期10分钟 2 基础版周期30分钟 NULL 一次性
    private Integer closeMark;          // 是否关闭 0/1
    private Timestamp monitorStartTime; // 周期任务监控开始时间 一次性和无限周期任务为NULL
    private Timestamp monitorEndTime;   // 周期任务监控结束时间 一次性和无限周期任务为NULL

    private Timestamp createTime;
    private Timestamp updateTime;

    /**
     * 周期执行时间间隔(单位：秒)
     * @return 0非周期 不等于 0 运行间隔
     */
    public long getSchedInterval() {
        if(taskCycleType != 1 || monitorLevel == null) {
            return 0L;
        } else if(monitorLevel == 1) {
            return 10 * 60L;
        } else if(monitorLevel == 2) {
            return 30 * 60L;
        } else {
            return 30 * 60L;
        }
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public String getMessageSN() {
        return messageSN;
    }

    public void setMessageSN(String messageSN) {
        this.messageSN = messageSN;
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    public Integer getMonitorType() {
        return monitorType;
    }

    public void setMonitorType(Integer monitorType) {
        this.monitorType = monitorType;
    }

    public String getMonitorValue() {
        return monitorValue;
    }

    public void setMonitorValue(String monitorValue) {
        this.monitorValue = monitorValue;
    }

    public Integer getTaskCycleType() {
        return taskCycleType;
    }

    public void setTaskCycleType(Integer taskCycleType) {
        this.taskCycleType = taskCycleType;
    }

    public Integer getMonitorLevel() {
        return monitorLevel;
    }

    public void setMonitorLevel(Integer monitorLevel) {
        this.monitorLevel = monitorLevel;
    }

    public Integer getCloseMark() {
        return closeMark;
    }

    public void setCloseMark(Integer closeMark) {
        this.closeMark = closeMark;
    }

    public Timestamp getMonitorStartTime() {
        return monitorStartTime;
    }

    public void setMonitorStartTime(Timestamp monitorStartTime) {
        this.monitorStartTime = monitorStartTime;
    }

    public Timestamp getMonitorEndTime() {
        return monitorEndTime;
    }

    public void setMonitorEndTime(Timestamp monitorEndTime) {
        this.monitorEndTime = monitorEndTime;
    }

    public Timestamp getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Timestamp createTime) {
        this.createTime = createTime;
    }

    public Timestamp getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Timestamp updateTime) {
        this.updateTime = updateTime;
    }

}
