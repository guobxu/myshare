package app.autodig.entity;

public enum MonitorType {

    A(1, "A"),
    AAAA(2, "AAAA"),
    CNAME(3, "CNAME"),
    NS(4, "NS"),
    MX(5, "MX"),
    TXT(6, "TXT");

    int type;
    String name;

    MonitorType(int type, String name) {
        this.type = type;
        this.name = name;
    }

    public static String get(int type) {
        if(type == 1) {
            return A.name;
        } else if(type == 2) {
            return AAAA.name;
        } else if(type == 3) {
            return CNAME.name;
        } else if(type == 4) {
            return NS.name;
        } else if(type == 5) {
            return MX.name;
        } else if(type == 6) {
            return TXT.name;
        }

        return null;
    }

    public String getName() {
        return name;
    }

    public static boolean isTXT(String monitorType) {
        return TXT.name.equals(monitorType);
    }

}
