package app.autodig.controller.advice;

import app.autodig.dto.ResponseDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import static org.springframework.http.HttpStatus.BAD_REQUEST;

@ControllerAdvice
@Component
@Order(Ordered.HIGHEST_PRECEDENCE)
public class RequestParamExceptionHandler {

    @ExceptionHandler(value = MethodArgumentTypeMismatchException.class)
    @ResponseBody
    @ResponseStatus(BAD_REQUEST)
    public ResponseDto handle(MethodArgumentTypeMismatchException exception) {
        String message = String.format("错误的请求参数类型: %s", exception.getName());

        return ResponseDto.errorByCodeAndMessage(BAD_REQUEST.value(), message);
    }


    @ExceptionHandler(value = MissingServletRequestParameterException.class)
    @ResponseBody
    @ResponseStatus(BAD_REQUEST)
    public ResponseDto handle(MissingServletRequestParameterException exception) {
        String message = String.format("参数是必须的: %s", exception.getParameterName());

        return ResponseDto.errorByCodeAndMessage(BAD_REQUEST.value(), message);
    }

}
