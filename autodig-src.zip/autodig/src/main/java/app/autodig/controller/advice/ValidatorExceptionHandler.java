package app.autodig.controller.advice;

import app.autodig.dto.ResponseDto;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.validation.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import static org.springframework.http.HttpStatus.BAD_REQUEST;

@ControllerAdvice
@Component
@Order(Ordered.HIGHEST_PRECEDENCE)
public class ValidatorExceptionHandler {


    @ExceptionHandler(value = MethodArgumentNotValidException.class)
    @ResponseBody
    @ResponseStatus(BAD_REQUEST)
    public ResponseDto handle(MethodArgumentNotValidException exception) {
        List<String> errors = exception.getBindingResult().getFieldErrors().stream()
                                    .map(e -> e.getField() + ": "  + e.getDefaultMessage())
                                    .collect(Collectors.toList());
        return ResponseDto.errorByCodeAndMessage(BAD_REQUEST.value(), String.format("错误的请求参数！%s", String.join("\n", errors)));
    }

    @ExceptionHandler(value = ConstraintViolationException.class)
    @ResponseBody
    @ResponseStatus(BAD_REQUEST)
    public ResponseDto handle(ConstraintViolationException exception) {
        List<String> errors = new ArrayList<>();
        for(ConstraintViolation violation : exception.getConstraintViolations()) {
            String mesg = violation.getMessage(), property = null;
            for(Path.Node node : violation.getPropertyPath()) {
                property = node.getName();
            }

            errors.add(property + ": " + mesg);
        }

        return ResponseDto.errorByCodeAndMessage(BAD_REQUEST.value(), String.format("错误的请求参数！%s", String.join("\n", errors)));
    }

}
