package app.autodig.controller;

import app.autodig.common.Constants;
import app.autodig.common.Utils;
import app.autodig.dto.RequestAuthDto;
import app.autodig.dto.ResponseDto;
import app.autodig.dto.TaskOpDto;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;

import static app.autodig.common.Constants.ENC_KEY;

@RestController
public class AuthController {

    private static final Logger LOGGER = LoggerFactory.getLogger(AuthController.class);

    @Value("${auth.systemID:}")
    private String authSystemID;

    @Value("${auth.hashCode}")
    private String authHashCode;

    @Value("${auth.tokenExpire:3600}")
    private int authTokenExpire;

    @RequestMapping(value = "/api/v1/SJPT/requestAuth", method = RequestMethod.POST)
    public ResponseDto requestAuth(@RequestBody @Valid @NotNull RequestAuthDto dto,
                                       HttpServletRequest request) throws Exception{
        String systemID = dto.getSystemID(), hashCode = dto.getHashCode(), messageSN = dto.getMessageSN();

        if(!authHashCode.equals(hashCode) ||    // 错误的hashCode
                ( Utils.isNotBlank(authSystemID) && !authSystemID.equals(systemID) )) { // 指定了systemID 但不匹配
            return ResponseDto.errorByCodeAndMessage(HttpStatus.BAD_REQUEST.value(), "认证失败，错误的hashCode 或者 systemID");
        }

        // 生成token
        long tokenExpireDate = System.currentTimeMillis() + (authTokenExpire * 1000L);
        String token = Utils.encryptAES(String.format("%s%s", request.getRemoteHost(), tokenExpireDate), ENC_KEY);
        String expireDatetime = new SimpleDateFormat(Constants.DATE_FORMAT).format(new Timestamp(tokenExpireDate));
        return ResponseDto.authSuccess(token, expireDatetime, messageSN);
    }

}
