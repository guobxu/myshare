package app.autodig.controller;

import app.autodig.common.Constants;
import app.autodig.common.Utils;
import app.autodig.dto.ResponseDto;
import app.autodig.dto.TaskOpDto;
import app.autodig.service.TaskService;
import org.hibernate.validator.constraints.NotBlank;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;

@RestController
@Validated
public class TaskController {

    public static final Logger LOGGER = LoggerFactory.getLogger(TaskController.class);

    @Autowired
    private TaskService taskService;

    @RequestMapping(value = "/open/api/v1/SJPT/DnsDomainTask", method = RequestMethod.POST)
    public ResponseDto opDomainDigTask(@RequestHeader(value = "Authorization") @NotBlank String token,
                                        @RequestBody @Valid @NotNull TaskOpDto dto,
                                         HttpServletRequest request) {
        if(!authRequestToken(token, request.getRemoteHost())) {
            return ResponseDto.taskOpTokenError(dto.getTaskId(), dto.getMessageSN());
        }

        return taskService.opTask(dto);
    }

    private boolean authRequestToken(String token, String requestIp) {
        if(!token.startsWith(Constants.BEARER_TOKEN_PREFIX)) {
            return false;
        }

        String tokenIp = null, tokenExpire = null;
        try {
            String text = Utils.decryptAES(token.substring(Constants.BEARER_TOKEN_PREFIX.length()), Constants.ENC_KEY);
            tokenIp = text.substring(0, text.length() - 13);
            tokenExpire = text.substring(text.length() - 13);

            if(!requestIp.equals(tokenIp) ||    // 非正确的ip地址
                    Long.parseLong(tokenExpire) < System.currentTimeMillis()) { // 已过期
                return false;
            }
        } catch(Exception ex) {
            LOGGER.error(ex.getMessage(), ex);

            return false;
        }

        return true;
    }

}
